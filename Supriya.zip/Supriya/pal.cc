#include <iostream>
#include <algorithm>
#include <string>

using namespace std;

const int MAX_LEN = 1000;
int ans;
int dp[MAX_LEN][MAX_LEN];

int isPal(string A){
    string r=A;
    reverse(A.begin(),A.end());
    if(A.compare(r)==0){
		// cout << __func__ << ": " << A << endl;
        return 1;
    }
    else 
    return 0;
}

void minCutUtil(string A, int start, int n, int count, int depth){
	if(dp[start][n] != 0) {
		ans = min(ans, dp[start][n]);
		return;
	}
	for(int i=0; i<depth; i++) cout << "\t";
	cout << "minCutUtil on " << start << " " << start+n-1 << endl;
    int i = start;
	// for(int i=start; i<start+n; i++){
        for(int j=start+n-1; j>=start; j--){
            if(A[i]==A[j]){
                if(isPal(A.substr(i,j-i+1))){
                    if(j-i+1==n){
                        if(count<ans){
							dp[start][n] = count;
                            ans=count;
                        }
                    }
                    else{
                        minCutUtil(A,j+1,n-(j-i+1),count+1, depth+1);
                    }
                }
            }
        }
    // }
}

int minCut(string A) {
    ans=100000;
    if(A.size()==1)
    return 0;
    int n=A.size();
    minCutUtil(A,0,n,0,0);
    return ans;
    // Do not write main() function.
    // Do not read input, instead use the arguments to the function.
    // Do not print the output, instead return values as specified
    // Still have a doubt. Checkout www.interviewbit.com/pages/sample_codes/ for more details
}


int main(int argc, char ** argv) {
	string s = "solomongrundy";
	ans = minCut(s);
	cout << ans << endl;
	return 0;
}
