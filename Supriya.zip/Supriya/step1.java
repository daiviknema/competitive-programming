import android.net.wifi.*;
import android.content.Context;
import java.util.List;
import java.util.TimerTask;
import java.util.Timer;
import android.view.KeyEvent;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.Intent;

WifiManager myWifiManager=(WifiManager)getSystemService(Context.WIFI_SERVICE);

//scanning for all APs in range
Vector<String>[] ssid=new Vector<String>[20];
Vector<String>[] macAdd=new Vector<String>[20];
Vector<int>[] rssi=new Vector<int>[20];
public static void main(String args[]){
for(int i=0;i<20;i++){
if(myWifiManager.isWifiEnabled())
{
	if(myWifiManager.startScan())
	{
		//List available APs
		List<ScanResult> scans = myWifiManager.getScanResults();   //.BSSID   .SSID   .level
		if(scans!=null && !scans.isEmpty())
		{
			for(ScanResult scan:scans)
			{
				ssid[i].addElement("\""+scan.SSID+"\"");
				macAdd[i].addElement("\""+scan.BSSID+"\"");
				rssi[i].addElement(scan.level);
				//int level = WifiManager.calculateSignalLevel(scan.level, 20);
				//other code
			}
		}
	}
}
}
}