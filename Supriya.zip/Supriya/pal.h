int ans;
int isPal(string A){
    string r=A;
    reverse(A.begin(),A.end());
    if(A.compare(r)==0){
        return 1;
    }
    else 
    return 0;
}

void minCutUtil(string A, int n, int count){
    
    for(int i=0;i<A.size();i++){
        for(int j=A.size()-1;j>=0;j--){
            if(A[i]==A[j]){
                if(isPal(A.substr(i,j-i+1))){
                    count++;
                    if(j-i+1==n){
                        if(count<ans){
                            ans=count;
                        }
                    }
                    else{
                        minCutUtil(A.substr(j+1,n-(j-i+1)),n-(j-i+1),count);
                    }
                }
            }
        }
    }
}

int Solution::minCut(string A) {
    ans=100000;
    if(A.size()==1)
    return 0;
    int n=A.size();
    minCutUtil(A,n,0);
    return ans-1;
    // Do not write main() function.
    // Do not read input, instead use the arguments to the function.
    // Do not print the output, instead return values as specified
    // Still have a doubt. Checkout www.interviewbit.com/pages/sample_codes/ for more details
}
