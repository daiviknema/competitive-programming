#include <iostream>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <map>
#include <list>
#include <cmath>

using namespace std;

int main(){
	//WifiManager myWifiManager=(WifiManager) getSystemService(Context.WIFI_SERVICE);
	int rpweights[20][5];
	string ssid;
	string macAdd;
	map<string,int> values;
	map<string,string> addresses;
	int rssi;
	int i=0;
	//if(myWifiManager.isWifiEnabled())
		//{
			//if(myWifiManager.startScan())
			//{
				//List available APs
				//list<ScanResult> scans = myWifiManager.getScanResults();   //.BSSID   .SSID   .level
				if(scans!=NULL && !scans.empty())
				{
					std::list<ScanResult>::const_iterator scan;
					for (scan = scans.begin(); scan != scans.end(); ++scan)
					{
						
						ssid="\""+scan.SSID+"\"";
						macAdd="\""+scan.BSSID+"\"";
						rssi=scan.level;
						addresses[macAdd]=ssid;
						values[macAdd]=rssi;
						//addresses.put(macAdd, ssid);
						//values.put(macAdd, rssi);
						//int level = WifiManager.calculateSignalLevel(scan.level, 20);
						//other code
					}
				}
				
			//}
		//}
		for(int i=0;i<20;i++){
			for(int j=0;j<5;j++){
				rpweights[i][j]=0;
			}
		}
		for (std::map<string,int>::iterator it=values.begin(); it!=values.end(); ++it){
			string MacAddress = it->first;
			int rssi = it->second;
			int mean=means[MacAddress];
			int std=stds[MacAddress];
			if(rssi>=(mean-std) && rssi<=(mean+std)){
				
			}
		}
	return 0;
}