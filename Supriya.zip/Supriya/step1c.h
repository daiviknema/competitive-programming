#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

int main(){
	//WifiManager myWifiManager=(WifiManager) getSystemService(Context.WIFI_SERVICE);
	string ssid;
	string macadd;
	//vector<vector<int>> rssi;
	//int rssi[5][20];
	/*for(int k=0;k<5;k++){
		for(int l=0;l<20;l++){
			rssi[k][l]=0;
		}
	}*/
	map<string, vector<int>> values;
	map<string, string> addresses;
	map<string, int> means;
	map<string, int> stds;
	int i=0;
	//int j=0;
	//timer
	/*public static void main(String args[]){
		Timer tasknew = new TimerScheduleAtFixedRate();
		Timer timer = new Timer();
		      
		// scheduling the task at fixed rate
		timer.scheduleAtFixedRate(tasknew,new Date(),30*1000);      
	}*/
	//if(myWifiManager.isWifiEnabled() && i<20)
	//{
		//if(myWifiManager.startScan())
		//{
			//List available APs
			//List<ScanResult> scans = myWifiManager.getScanResults();   //.BSSID   .SSID   .level
			if(scans!=NULL && !scans.empty())
			{
				std::list<ScanResult>::const_iterator scan;
				for (scan = scans.begin(); scan != scans.end(); ++scan) {
					//std::cout << *scan;
					ssid="\""+scan.SSID+"\"";
					macAdd="\""+scan.BSSID+"\"";
					values[macAdd].push_back(scan.level);
					//rssi[j].push_back(scan.level);
					addresses.insert ( std::pair<string,string>(macAdd,ssid) );
					//values.insert(std::pair<string,int[20]>(macAdd,rssi[j]));
					//j++;
					//int level = WifiManager.calculateSignalLevel(scan.level, 20);
					//other code
				}
				i=i+1;
			}
			
		//}
	//}
	else if(i==20){
		for (std::map<string,vector<int>>::iterator it=values.begin(); it!=values.end(); ++it){
			string MacAddress=iterator->first;
			vector<int> rssis;
			rssis=iterator->second;
			int sum=0;
			for(int j=0;j<rssis.size();j++){
				sum+=rssis[j];
			}
			int mean=sum/rssis.size();
			means[MacAddress]=mean;
			for(int j=0;j<rssis.size();j++){
				rssis[j]=pow(rssis[j]-mean,2);
			}
			sum=0;
			for(int j=0;j<rssis.size();j++){
				sum+=rssis[j];
			}
			int std=sqrt(sum/rssis.size());
			stds[MacAddress]=std;
		}
	}
}