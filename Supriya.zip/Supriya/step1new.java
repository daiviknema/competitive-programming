import android.net.wifi.*;
import android.content.Context;
import java.util.List;
import java.util.TimerTask;
import java.util.Timer;
import android.view.KeyEvent;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.Intent;

//in onCreate method

WifiManager myWifiManager=(WifiManager)getSystemService(Context.WIFI_SERVICE);
boolean wasEnabled=myWifiManager.isWifiEnabled();
myWifiManager.setWifiEnabled(true);
while(!myWifiManager.isWifiEnabled()){} //empty while loop while wifi is being activated


//code for how to end when the back button is pressed

public boolean onKeyDown(int keyCode, KeyEvent event)
{
	if(keyCode==KeyEvent.KEYCODE_BACK)
	{
		myWifiManager.setWifiEnabled(wasEnabled);
		this.finish();
	}
	return super.onKeyDown(keyCode, event);
}

//scanning for all APs in range
Vector<String> ssid[20];
Vector<String> macAdd[20];
Vector<int> rssi[20];
if(myWifiManager.isWifiEnabled())
{
	if(myWifiManager.startScan())
	{
		//List available APs
		List<ScanResult> scans = myWifiManager.getScanResults();   //.BSSID   .SSID   .level
		if(scans!=null && !scans.isEmpty())
		{
			for(ScanResult scan:scans)
			{
				ssid[i].addElement("\""+scan.SSID+"\"");
				macAdd[i].addElement("\""+scan.BSSID+"\"");
				rssi[i].addElement(scan.level);
				//int level = WifiManager.calculateSignalLevel(scan.level, 20);
				//other code
			}
		}
	}
}

//create a new BroadcastReceiver and register that receiver with 
//the message that is posted by the WifiManager

IntentFilter i=new IntentFilter();
i.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
registerReceiver(new BroadcastReceiver()
{
	@Override
	public void onReceive(Context c, Intent i)
	{
		//code to execute when SCAN_RESULTS_AVAILABLE_ACTION event occurs
		myWifiManager=(WifiManager)c.getSystemService(Context.WIFI_SERVICE);
		List<ScanResult> wireless=myWifiManager.getScanResults();
		//returns a <list> of scanResults
	} 
}
,i);

//CONNECTING TO A NETWORK

//check the levels of each AP

myWifiManager.compareSignalLevel(scan.level, scan2.level);

//so that the device stays connected to the network

myWifiManager.enableNetwork(id, true);

List<ScanResult> wireless = myWifiManager.getScanResults();
for(ScanResult scan:wireless)
{
	if(scan.BSSID.equals(desiredMACAddress))
	{
		boolean cont = true;
		for(WifiConfiguration w: myWifiManager.getConfiguredNetworks())
		{
			String s="\""+scan.SSID+"\"";
			String bs=scan.BSSID;
			if((w.SSID!=null && w.SSID.equals(s))||(w.BSSID!=null && w.BSSID.equals(bs)))
			{
				cont = false;
				break;
			}
		}
		if(cont)
		{
			WifiConfiguration config= new WifiConfiguration();
			config.SSID="\""+scan.SSID+"\"";
			config.BSSID=scan.BSSID;
			config.priority=1;
			config.preSharedKey="\""+"PASSWORD"+"\"";
			
			config.status=WifiConfiguration.Status.DISABLED;
			config.status = WifiConfiguration.Status.CURRENT;
			config.status = WifiConfiguration.Status.ENABLED;
			
			config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.IEEE8021X);
			config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
			config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
			config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_EAP);
			
			config.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.TKIP);
			config.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);
			config.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.NONE);
			
			config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
			config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
			config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP104);
			config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);
			
			config.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.OPEN);
			config.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.SHARED);
			config.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.LEAP);

			config.allowedProtocols.set(WifiConfiguration.Protocol.WPA);
			config.allowedProtocols.set(WifiConfiguration.Protocol.RSN);
			
			id=myWifiManager.addNetwork(config);
			myWifiManager.enableNetwork(id, true);
			myWifiManager.saveConfiguration();

		}
	}
}

//removing saved network configurations

for(WifiConfiguration config: myWifiManager.getConfiguredNetworks())
{
	if(config.SSID=="\""+"DESIRED SSID"+"\"")
	{
		myWifiManager.removeNetwork(config.networkId);
		break;
	}
}
