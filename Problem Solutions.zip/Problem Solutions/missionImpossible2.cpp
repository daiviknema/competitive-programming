#include <iostream>
#include <stdio.h>

using namespace std;

int r, c;
int Dx[] = {-1, 1, 0, 0};
int Dy[] = {0, 0, 1, -1};

#define M 11
#define INF 999999999

int cost_fire[M][M];// Bomb affecting time array
int cost_joe[M][M];// ethan movement time array

int map[M][M];// Input array

void print_cost_fire()
{
      for(int i = 0; i < r; ++i){
          for(int j = 0; j < c; ++j)
           {
              cout << cost_fire[i][j] << " ";
           }
           cout << endl;
      }
}


void print_cost_joe()
{
      for(int i = 0; i < r; ++i){
          for(int j = 0; j < c; ++j)
           {
              cout << cost_joe[i][j] << " ";
           }
           cout << endl;
      }
}

typedef struct
{
    int x;
    int y;
}point;

point q[M * M * 10];

int rear = -1, front = 0;

void init()
{
     for(int i = 0; i < M; ++i)
     for(int j = 0; j < M; ++j)
     {
        cost_fire[i][j] = INF;
        cost_joe[i][j] = INF;
     }
     rear = -1;
     front = 0;
     return;
}

int is_safe(int nx, int ny)
{
    if(nx >= 0 && nx < r && ny >= 0 && ny < c)
          return 1;
    return 0;
}

void bfs_fire()
{
     while(rear >= front)
     {
           point ref = q[front++];
           int rx = ref.x;
           int ry = ref.y;

           for(int j = 0; j < 4; ++j)
           {
               int nx = ref.x + Dx[j];
               int ny = ref.y + Dy[j];

               if(is_safe(nx, ny) && map[nx][ny] != 1 && cost_fire[nx][ny] > cost_fire[rx][ry] + 1)
               {
                         point tmp;
                         tmp.x = nx; tmp.y = ny;
                         cost_fire[nx][ny] = cost_fire[rx][ry] + 1;
                         q[++rear] = tmp;
               }
           }
     }
     return;
}

void bfs_joe(int jx, int jy)
{
     rear = -1; front = 0;
     point tmp_j;

     tmp_j.x = jx;  tmp_j.y = jy;
     q[++rear] = tmp_j;
     cost_joe[jx][jy] = 0;

     while(rear >= front)
     {
           point ref = q[front++];
           int rx = ref.x;
           int ry = ref.y;

           for(int j = 0; j < 4; ++j)
           {
               int nx = ref.x + Dx[j];
               int ny = ref.y + Dy[j];

               if(is_safe(nx, ny) &&
               map[nx][ny] != 1 &&
               cost_joe[nx][ny] > cost_joe[rx][ry] + 1 &&
               cost_joe[rx][ry] + 1 < cost_fire[nx][ny])
               {
                         point tmp;
                         tmp.x = nx; tmp.y = ny;
                         cost_joe[nx][ny] = cost_joe[rx][ry] + 1;
                         q[++rear] = tmp;
               }
           }
     }
     return;
}

int min_t()
{
      int res = INF;
      for(int i = 0; i < r; ++i)
        for(int j = 0; j < c; ++j)
      {
         if((i == 0 || j == 0 || i == (r - 1) || j == (c - 1)) &&
              res > cost_joe[i][j])
               res = cost_joe[i][j];
      }
      return res;
}

int main()
{
    int tc;
    cin >> tc;

    while(tc--)
    {
         init();
         cin >> r >> c;

         for(int i = 0; i < r; ++i)
         for(int j = 0; j < c; ++j)
            cin >> map[i][j];

         int jx, jy;

         for(int i = 0; i < r; ++i)
          for(int j = 0; j < c; ++j)
           {
              if(map[i][j] == 2)//bomb location
              {
                 point tmp;
                 tmp.x = i; tmp.y = j;
                 q[++rear] = tmp;
                 cost_fire[i][j] = 0;
              }
              if(map[i][j] == 3)//ethan location
              {
                 jx = i;
                 jy = j;
              }
           }

          bfs_fire();

          bfs_joe(jx, jy);

          int ans = min_t();

          if(ans == INF)
             printf("-1\n");
          else
             printf("%d\n", ans + 1);
    }

    return 0;
}
