#include <iostream>
using namespace std;
#define INTMAX 10000000
#define llong long long int
llong ite, n, sum;
llong l[100000];
llong r[100000];
llong arr[1000001];

void mergeArray(int p, int q, int r1){
    llong n1 = q-p+1;
    llong n2 = r1-q;
    for(int i=1;i<=n1;i++)
        l[i] = arr[p+i-1];
    for(int i=1;i<=n2;i++)
        r[i] = arr[q+i];
     l[n1+1] = INTMAX;
     r[n2+1] = INTMAX;
     llong i=1, j=1;
     for(int s = p;s<=r1;s++){
        if(l[i] <= r[j])
            arr[s] = l[i++];
        else{
            arr[s] = r[j++];
        }
     }
}

void mergeSort(int p, int q){
    if(p<q){
        int m = (p+q)/2;
        mergeSort(p,m);
        mergeSort(m+1,q);
        mergeArray(p,m,q);
    }
}

int main() {
    cin >> ite;
    for(int tc=1;tc<=ite;tc++) {
        cin >> n;
        sum=0;
        for(int i=1;i<=n;i++) {
            cin >> arr[i];
            sum+=arr[i];
        }
        mergeSort(1,n);
        for(int i=n-2;i>=0;i-=3)
            sum-=arr[i];
        cout << "#" << tc << " " << sum << endl;
    }
    return 0;
}
