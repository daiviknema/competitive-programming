#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int n;
char a, b, c;
char str[3];
int start, middle, end, single;
int ans;

int main()
{
	int T;
	scanf("%d", &T);
	int t;
	for (t = 1; t <= T; t++)
	{
		ans = 0;
		start = 0;
		middle = 0;
		end = 0;
		single = 0;

		scanf("%d", &n);
		int i, j=1, k=1, l=1;
		for (i = 1; i <= n; i++)
		{
			scanf("%s", str);
			a = str[0];
			b = str[1];
			c = str[2];
			if (a != '*' && b != '*' && c != '*')
				ans += (a - '0') + (b - '0') + (c - '0');
			
			else if (a == '*')
			{
				if (b == '*' && c != '*')
				{
					if (start < (c - '0'))
						start = c - '0';
				}
				else if (b != '*' && c != '*')
				{
					if (start < ((b - '0') + (c - '0')))
						start = (b - '0') + (c - '0');
				}
				else if (b != '*' && c == '*')
				{
					if (single < (b - '0'))
						single = b - '0';
				}
			}

			else if (a != '*')
			{
				if (b == '*' && c == '*')
				{
					if (end < (a - '0'))
						end = a - '0';
				}
				else if (b != '*' && c == '*')
				{
					if (end < ((a - '0') + (b - '0')))
						end = (a - '0') + (b - '0');
				}
				else if (b == '*' && c != '*')//mid '*' means it wiln't add in start or end.
				{
					if (middle < ((a - '0') + (c - '0')))
						middle = (a - '0') + (c - '0');
				}
			}
		}

		if ((start + end) > middle)
			ans += start + end;
		else
			ans += middle;

		if (single > ans)////"*2* it willn't add it will consider as single element
			ans = single;
			
		printf("#%d %d\n", t, ans);
	}
	return 0;
}