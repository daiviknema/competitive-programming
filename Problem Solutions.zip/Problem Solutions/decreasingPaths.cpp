using namespace std;
#include <iostream>
#include<cstdio>
#define modd 1000000007

int N;
int grid[1010][1010];

int processed[1010][1010];
long long int paths[1010][1010];
long long int answer;
int dx[] = {0,0,1,-1};
int dy[] = {1,-1,0,0};

bool isSafe(int x, int y){
    if(x>=0 && x<N && y>=0 && y<N)
        return true;
    else
        return false;
}

long long int dfs(int sX, int sY) {
    if(processed[sX][sY]==1)
        return paths[sX][sY];

    processed[sX][sY]=1;

    for(int i=0;i<4;i++) {
        int nX = sX+dx[i];
        int nY = sY+dy[i];
        if(isSafe(nX,nY) && grid[sX][sY]>grid[nX][nY])
            paths[sX][sY] = (paths[sX][sY]+ dfs(nX, nY))%modd;
    }

    return paths[sX][sY];
}

int main() {
    int t;
    cin >> t;
    for(int cs=1;cs<=t;cs++) {
        cin >> N;

        answer = 0;

        for(int i=0;i<N;i++)
        for(int j=0;j<N;j++) {
         //   visited[i][j] = 0;
            processed[i][j] = 0;
            paths[i][j] = 1;
            scanf("%d",&grid[i][j]);
        }

        for(int i=0;i<N;i++)
        for(int j=0;j<N;j++) {
            dfs(i, j);
        }

        for(int i=0;i<N;i++)
        for(int j=0;j<N;j++)
            answer = (answer + paths[i][j])%modd;

       // cout << "Case #" << cs << endl;
        cout << answer << endl;

    }
    return 0;
}
