#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int ans;
int n,k;

int fun(int pies, int k, int pietofront)
{
	if (pies == 0 && k >= 0)
		return 0;
	if (pies > 0 && k == 1)
	{
		ans++;
		return 0;
	}
	int i;
	int max = pies / k;
	for (i = pietofront; i <= max; i++)
		fun(pies - i, k - 1, i);
}

int main()
{
	int T;
	scanf("%d", &T);

	int t;
	for (t = 1; t <= T; t++)
	{
		ans = 0;
		scanf("%d %d", &n, &k);

		fun(n, k, 1);
		printf("Case #%d\n%d\n",t,ans);
	}
	return 0;
}