#include <iostream>
using namespace std;
#define N 20
int grid[N][N];
int visited[N][N];
int t, n, found=0;
int dx[]={0,0,1,-1};
int dy[]={1,-1,0,0};

bool isSafe(int i, int j){
    if(visited[i][j]==0 && grid[i][j]!=1 && i>=0 && j>=0 && i<n && j<n) return true;
    return false;
}

bool isSafe1(int bx,int by, int i, int j){
    if(grid[bx][by]==0 && bx>=0 && by>=0 && bx<n && by<n && (bx!=i || by!=j)) return true;
    return false;
}

void swapp(int i, int j, int k, int l){
    int t = grid[i][j];
    grid[i][j] = grid[k][l];
    grid[k][l] = t;
}

void printGrid() {
    cout <<endl;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cout << grid[i][j] << " ";
        }
        cout << endl;
    }
    cout <<endl;
}

void dfs(int i, int j) {

    if(i==n-1 && j==n-1)
        found=1;
    if(found==1)    return;

    for(int ii=0;ii<4;ii++){
        int nx = i+dx[ii];
        int ny = j+dy[ii];

        if(isSafe(nx,ny)) {
            if(grid[nx][ny]==0){
                visited[nx][ny] = 1;
                dfs(nx, ny);
                visited[nx][ny] = 0;
            }
            else {
                for(int jj=0;jj<4;jj++){
                    int bx = nx+dx[jj];
                    int by = ny+dy[jj];
                    if(isSafe1(bx, by, i, j)){ // move block to one of the possible direction
                        swapp(bx,by,nx,ny);
                        visited[nx][ny] = 1;
                        dfs(nx,ny);
                        visited[nx][ny] = 0;
                        swapp(bx,by,nx,ny);
                    }
                }
            }
        }
    }
}


int main() {
    cin >> t;
    for(int tc=1;tc<=t;tc++) {
        cin >> n;
        found=0;
        for(int i=0;i<n;i++)
            for(int j=0;j<n;j++)    cin >> grid[i][j], visited[i][j]=0;
        if(grid[0][0]==0){
            visited[0][0] = 1;
            dfs(0,0);
            cout << found << endl;
        }
    }
    return 0;
}
