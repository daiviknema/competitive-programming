#include <iostream>
using namespace std;

int t, n;
int scores[20000];
int arr[20000];

int main() {
    cin >> t;
    for(int tc=1;tc<=t;tc++) {
        cin >> n;
        for(int i=0;i<20000;i++)    scores[i] = 0;
        int idx=0, preidx=0, num, maxSum=0;
        arr[0] = 0;
        scores[0] = 1;

        for(int i=0;i<n;i++) {
            cin >> num;
            for(int j=0;j<=idx;j++){
                int newSum = arr[j] + num;
                maxSum = maxSum < newSum ? newSum : maxSum;
                if(scores[newSum]==0) {
                    scores[newSum] = 1;
                    arr[++preidx] = newSum;
                }
            }
            idx = preidx;
        }
        for(int i=1;i<=maxSum;i++)    scores[0]+=scores[i];
        cout << "#" << tc << " " << scores[0] << endl;
    }
    return 0;
}
