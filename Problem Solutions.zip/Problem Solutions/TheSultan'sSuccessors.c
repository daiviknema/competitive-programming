#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int arr[9][9];
int ans;

int isSafe(int row, int col)
{
	int i, k;
	for (i = 1; i < row; i++)
		if (arr[i][col] == -1)
			return 0;

	for (k = 1; k <= 8; k++)
	{
		if (row - k > 0 && col - k > 0 && arr[row - k][col - k] == -1)
			return 0;
		if (row - k > 0 && col + k <= 8 && arr[row - k][col + k] == -1)
			return 0;
	}
	return 1;
}

int fun(int row, int sum)
{
	if (row > 8)
	{
		if (sum > ans)
			ans = sum;
		return 0;
	}

	int i;
	for (i = 1; i <= 8; i++)
	{
		if (isSafe(row, i))
		{
			int temp = arr[row][i];
			arr[row][i] = -1;
			fun(row + 1, sum + temp);
			arr[row][i] = temp;
		}
	}
	return 0;
}

int main()
{
	int T;
	scanf("%d", &T);
	int t;
	for (t = 1; t <= T; t++)
	{
		ans = 0;
		int i, j;
		for (i = 1; i <= 8; i++)
		for (j = 1; j <= 8; j++)
			scanf("%d", &arr[i][j]);
		fun(1, 0);
		printf("%5d\n", ans);
	}
	return 0;
}