import java.io.File;
import java.util.Scanner;


class BaloonShooting {
	
	int n,k,aa[],t;
	int answer;
	//int temp[], tempcount;
	
	public BaloonShooting(int N1, int K1, int A1[], int T1){
		
		n=N1;
		k=K1;
		
		aa= new int[n];
		aa=A1;
		
		t=T1;
		
		//temp= new int[10000];
		
	}
	
	public void recurr(int a[], int count, boolean condition) {

		if (condition) {

			condition = false;

			for (int i = 1; i <= count - 2; i++) {

				if (a[i] - a[i - 1] == k && a[i + 1] - a[i] == k) {

					condition = true;

					int x = a[i];
					int y = a[i - 1];
					int z = a[i + 1];

					a[i] = -1;
					a[i - 1] = -1;
					a[i + 1] = -1;

					// array update , func call
					int tempcount = 0;
					int temp[] = new int[n];

					for (int j = 0; j < count; j++) {
						if (a[j] != -1) {
							temp[tempcount] = a[j];
							tempcount++;
						}
					}

					recurr(temp, tempcount, condition);

					a[i] = x;
					a[i - 1] = y;
					a[i + 1] = z;

				}

			}

		}
		if (answer > count) {
			answer = count;
		}

	}
	
	public void startAlgo(){
		
			
		boolean condition=true;
		int count=n;
		answer=9999;
		
		recurr(aa,count,condition);
		
		
		System.out.println("#"+t+" "+ answer);
		
		
	}
	
	public static void main(String[] args)throws Exception{
		
		int T,n,k,a[];

		
		Scanner sc=new Scanner(new File("C:\\Users\\abhishek.l\\Desktop\\inputs\\BaloonShooting.txt"));
		//Scanner sc= new Scanner(System.in);
		T=sc.nextInt();
		
		for(int t=0;t<T;t++){
			
			n= sc.nextInt();
			k=sc.nextInt();
			
			a=new int[n];
			
			for(int i=0;i<n;i++)
				a[i]=sc.nextInt();
			
			BaloonShooting bs= new BaloonShooting(n,k,a,t+1);
			bs.startAlgo();
			
		}
		
		
		
		sc.close();
	}

}
