package SelfPractice;

import java.io.FileInputStream;
import java.util.Scanner;

public class BalloonShooting {
	static int N,a[],K,n;
	static long Answer;

	public static void main(String args[]) throws Exception	{
		Scanner sc = new Scanner(System.in);
		sc = new Scanner(new FileInputStream("BalloonShooting_sample_input.txt"));

		int T = sc.nextInt();
		for(int test_case = 1; test_case <= T; test_case++) {
			N = sc.nextInt();
			K = sc.nextInt();
			a = new int[N];

			for(int i=0;i<N;i++){
				a[i] = sc.nextInt();
			}
			Answer = Integer.MAX_VALUE;
			if(N==1 || N==2){
				Answer=N;
			} else{
				for(int i=0;i<N-2;i++){
					shootBalloon(i,a,N);
				}
			}
			System.out.println("#"+test_case+" "+Answer);
		}
	}

	private static void shootBalloon(int idx,int arr[],int n) {

		if(idx>=n-2){
			int size = arr.length;
			if(Answer>size)
				Answer = size;
			return;
		}

		//In case c-b=b-c==k gets true then also don't shoot it, go to next idx.
		shootBalloon(idx+1,arr,arr.length);
		
		//In case c-b=b-c==k gets true then shoot it. and resize array
		if((arr[idx+2]-arr[idx+1]==K) && (arr[idx+1]-arr[idx]==K)){
			n = n-3;
			int[]  temp = new int[n];
			int p =0;
			for(int i=0;i<arr.length;i++) {
				if(i!=idx && i!=idx+1 && i!=idx+2)
					temp[p++]=arr[i];
			}

			if(idx>=2)  //After resizing array again start from idx-2. no need to start from 0 index
				shootBalloon(idx-2,temp,n);     //It is neccessary to prevent Time out.
			else
				shootBalloon(0,temp,n);
		}
	}
}
