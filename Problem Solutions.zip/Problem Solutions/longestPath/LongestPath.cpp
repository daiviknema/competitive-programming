#include <iostream>
using namespace std;
int N = 0;
int ary[50][50] = {0,};
int max_path = -1;
int visited[50][50] = {0,};
int g_visited[50][50] = {0,};
int maxi = 0, maxj = 0;


bool isSafe(int row, int col) {
	if(row >= 0 && row < N
       && col >= 0 && col < N
       && !visited[row][col]
       && ary[row][col] == 1) return true;
	return false;
}

int dx[] = {1, 0, -1, 0};
int dy[] = {0, 1, 0, -1};

void searchLongestPath_1(int row, int col, int maxpath) {
	if(maxpath > max_path) {
		maxi = row;
		maxj = col;
		max_path = maxpath;
	}

	visited[row][col] = 1;

	for(int k = 0; k < 4; k++) {
		int r = row + dx[k];
		int c = col + dy[k];
		if(isSafe(r, c)) {
			searchLongestPath_1(r, c, maxpath+1);
		}
	}
	visited[row][col] = 0;
}









void searchLongestPath_2(int row, int col, int maxpath) {

	if(maxpath > max_path) max_path = maxpath;

	visited[row][col] = 1;
	g_visited[row][col] = 1; //optimization for not starting dfs for each element in main
	for(int k = 0; k < 4; k++) {
		int r = row + dx[k];
		int c = col + dy[k];
		if(isSafe(r, c)) {
			searchLongestPath_2(r, c, maxpath+1);
		}
	}
	visited[row][col] = 0;
}

void searchPath(int row, int col, int *cost) {

	int maxcost = 1;
	searchLongestPath_1(row, col, maxcost);

	for(int i = 0; i < N; i++) {
		for(int j = 0; j < N; j++) {
			visited[i][j] = 0;
		}
	}

	searchLongestPath_2(maxi, maxj, maxcost);

    for(int i = 0; i < N; i++) {
		for(int j = 0; j < N; j++) {
			if(g_visited[i][j] == 1) ary[i][j] = 0;
		}
	}
}

int main(int argc, char* argv[])
{
	//freopen("input_sample.txt", "r", stdin);
	int tests = 0;
	cin>>tests;
	for(int i = 0; i < tests; i++) {
		N = 0;
		max_path = -1;
		maxi = maxj = 0;
		cin>>N;
		for(int i = 0; i < N; i++) {
			for(int j = 0; j < N; j++) {
				cin>>ary[i][j];
				visited[i][j] = 0;
				g_visited[i][j] = 0;
			}
		}

		for(int i = 0; i < N; i++) {
			for(int j = 0; j < N; j++) {
				if(ary[i][j] == 1) {
					int path_len = 0;
					searchPath(i, j, &path_len);
					//if(path_len > max_path) max_path = path_len;
				}
			}
		}
		cout<<"Case #"<<i+1<< " " <<max_path<<endl;
	}
	return 0;
}
