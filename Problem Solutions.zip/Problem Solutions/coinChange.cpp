#include <iostream>
using namespace std;
int t, N;
int c[5];
int q[5];
int answer;
int ans=0;
void dfs(int idx, int value, int coin) {
   if (value > N)
        return;

    if (idx == 5 || value == N) {
        //cout << idx << " " << value << " " << coin << endl;
        if (value < N)
            coin = coin + N - value;
        if (coin < ans)
                ans = coin;
        return;
    }
    else {
        for (int i=0;i<=q[idx];i++) {
            dfs(idx + 1, value+(c[idx] * i), coin + i);
        }
    }
}


void findChange(int i, int coins, int m) {
    if(m<0) return;
    if(i==5 || m==0) {
        if(m>0)coins = coins+m;
        answer = answer>coins?coins:answer;
        return;
    }
    for(int j=0;j<=q[i];j++)
        findChange(i+1,coins+j,m-j*c[i]);
}

int main() {
    cin >> t;
    for(int tc = 1;tc<=t;tc++) {
        for(int i=0;i<5;i++)
            cin >> c[i] >> q[i];
        cin >> N;
        answer = N;
        ans=N;
       // findChange(0, 0, N);
        dfs(0, 0, 0);
      //  cout << "#" << tc << " " << answer << endl;
        cout << "#" << tc << " " << ans << endl;
    }
    return 0 ;
}
