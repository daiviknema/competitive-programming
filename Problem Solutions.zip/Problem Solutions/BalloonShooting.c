#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int ans;
int n, K;
int balloons[46];

int fun(int arr[], int size, int count)
{
	if (n - count <= 2)
	{
		ans = count;
		return 0;
	}

	int i, j, k;
	int flag=0;
	for (i = 1; i <= size - 2; i++)
	{
		if (arr[i + 1] - arr[i] == K && arr[i + 2] - arr[i + 1] == K)
		{
			flag = 1;
			int arr_p[45];
			for (j = 1; j < i; j++)
				arr_p[j] = arr[j];
			for (k = i + 3; k <= size; k++)
				arr_p[j++] = arr[k];
			fun(arr_p, size - 3, count + 3);
		}
	}

	if (flag == 0)
	{
		if (count > ans)
			ans = count;
		return 0;
	}
}

int main()
{
	int T;
	scanf("%d", &T);

	int t;
	for (t = 1; t <= T; t++)
	{
		ans = 0;
		scanf("%d %d", &n, &K);

		int i;
		for (i = 0; i <= 45; i++)
			balloons[i] = 0;
			
		for (i = 1; i <= n; i++)
			scanf("%d", &balloons[i]);

		fun(balloons,n,0);
		printf("#%d %d\n", t, n-ans);
	}
	return 0;
}