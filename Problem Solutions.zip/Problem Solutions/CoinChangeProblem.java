package SelfPractice;

import java.util.Scanner;

public class CoinChangeProblem {
	static int N, denomination[],quantity[],minCoinCount;

	public static void main(String args[]) throws Exception	{
		Scanner sc = new Scanner(System.in);
		//sc = new Scanner(new FileInputStream("NumberTriangle_sample_input.txt"));

		int TC = sc.nextInt();
		for(int test_case = 1; test_case <= TC; test_case++) {
			denomination = new int[5];
			quantity = new int[5];
			for(int i=0;i<5;i++){
				denomination[i] = sc.nextInt();
				quantity[i] = sc.nextInt();
			}
			N = sc.nextInt();
			minCoinCount = Integer.MAX_VALUE;
			calculate(0,0,0);
			System.out.println("#"+test_case+" "+minCoinCount);
		}
	}

	private static void calculate(int index, int amount, int coinCount) {
		
		if((amount<N && index>=5) || coinCount>=minCoinCount)
			return;

		if(amount==N){
			if(minCoinCount>coinCount)
				minCoinCount = coinCount;
			return;
		}

		calculate(index+1,amount,coinCount);

		for(int j=1;;j++){
			if(amount+(denomination[index]*j)<=N && j<=quantity[index])
				calculate(index+1,amount+(denomination[index]*j),coinCount+j);
			else
				break;
		}
	}
}
