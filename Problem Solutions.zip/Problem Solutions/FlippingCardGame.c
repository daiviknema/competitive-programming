#include <stdio.h>

int ans;

int main()
{
    int T;
    scanf("%d",&T);
    int t;
    for(t=1;t<=T;t++)
    {
         int a, b;
         scanf("%d%d",&a,&b);
         ans = 0;
         while(a % 4 != 0 && a <= b)
         {
             ans = ans ^ a;
             a++;
         }
         while(b >= a)
         {
            ans = ans ^ b;
            if(b % 4 == 0)break;
            b--;
         }
         printf("#%d %d\n", t, ans);
    }
    return 0;
}