#include<stdio.h>
#define MAX 9999999
int b[11], vis[11], a[11], field[21][21], res, startX, startY, row, col, N;
struct beepers
{
    int x;
    int y;
};
struct beepers point[11];
void permute(int, int);
int main()
{
    int T, tc, i;
//  freopen("input.txt", "r", stdin);
    scanf("%d", &T);
    for (tc = 1; tc <= T; tc++)
    {
        scanf("%d%d%d%d%d", &row, &col, &startX, &startY, &N);
        for (i = 1; i <= N; i++){
            scanf("%d", &point[i].x);
            scanf("%d", &point[i].y);
        }
        res = MAX;
        permute(1, 0);
        printf("The shortest path has length %d\n", res);
    }
//  _getch();
    return 0;
}

void permute(int idx, int cost)
{
    int i, dx = 0, dy = 0;
    //TERMINATION
    if (idx == N + 1)
    {
        dx = startX - point[b[idx-1]].x;
        dy = startY - point[b[idx-1]].y;
        if (dx < 0) dx = dx * -1;
        if (dy < 0) dy = dy * -1;
        if (cost + dx + dy < res)
            res = cost + dx + dy;
        return;
    }
    //PRUNING
    if (cost > res)
        return;

    //PERMUTATIONS
    for (i = 1; i <= N; i++)
    {
        if (vis[i] == 0)
        {
            vis[i] = 1;
            b[idx] = i;
            if (idx == 1)
            {
                dx = startX - point[b[idx]].x;
                dy = startY - point[b[idx]].y;
                if (dx < 0) dx = dx * -1;
                if (dy < 0) dy = dy * -1;
            }
            else {
                dx = point[b[idx]].x - point[b[idx - 1]].x;
                dy = point[b[idx]].y - point[b[idx - 1]].y;
                if (dx < 0) dx = dx * -1;
                if (dy < 0) dy = dy * -1;
            }
            permute(idx + 1, cost + dx + dy);
            vis[i] = 0;
            b[idx] = 0;
        }
    }
}
