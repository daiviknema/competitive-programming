#include <stdio.h>
#include <string.h>
#include <iostream>
using namespace std;

char input[100];
char permutation[100];
int visited[100];
char subset[100];

void init() {
    for(int i=0;i<100;i++)  visited[i] = 0;
}

void swap(char *x, char *y) {
    char temp;
    temp = *x;
    *x = *y;
    *y = temp;
}

void permute(char *a, int l, int r) {
   int i;
   if (l == r)
     printf("%s\n", a);
   else {
       for (i = l; i <= r; i++) {
          swap((a+l), (a+i));
          permute(a, l+1, r);
          swap((a+l), (a+i)); //backtrack
       }
   }
}

void permute2(int idx, char s[], int N) {
    if(idx == N)
        cout << s << endl;
    for(int i=0;i<N;i++) {
        if(visited[i] == 0) {
            visited[i] = 1;
            s[idx] = input[i];
            permute2(idx+1, s, N);
            visited[i] = 0;
        }
    }
}

void subsets(int idx, int N) {
//  Prints a set multiple times.
    for(int i=0;i<N;i++)
        if(visited[i] == 1)
            cout << input[i];
    cout << endl;
    for(int i=0;i<N;i++) {
        if(visited[i] == 0) {
            visited[i] = 1;
            subsets(idx+1, N);
            visited[i] = 0;
        }
    }
}

void subsets2(int idx, char s[], int index,  int n){
    if(idx == n){
        for(int i=0;i<index;i++)
            cout << s[i] << " ";
        cout << endl;
        return;
    }
    subsets2(idx+1, s, index, n);
    s[index] = input[idx];
    subsets2(idx+1, s, index+1, n);
}

int main() {
    init();
    cin >> input;
    cout << "Input is " << input << endl;

    int length = 0;
    for(length = 0 ; input[length]!='\0' ; length++);
    int n = length;

    cout << "Permutation from method 1 : " << endl;
    permute(input, 0, n-1);

    cout << endl<< "Permutation from method 2 : " << endl;
    permute2(0,permutation, n);

    cout << endl << "All Subsets from method 1 : " << endl;
    subsets(0, n);

    cout << endl << "All Subsets from method 2 : " << endl;
    subsets2(0, subset, 0, n);
    return 0;
}
