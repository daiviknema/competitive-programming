using namespace std;
#include <iostream>

#define N 200
int dist[N][N];
int t, m, n;
char c;

struct cell{
    int x;
    int y;
};

cell Q[1000000];
int frontt = -1;
int backk = -1;

void reset(){
    frontt = -1;
    backk = -1;
}

int queueSize(){
    return backk-frontt;
}

bool isEmpty(){
    return (frontt==backk);
}

void enqueue(cell x) {
    Q[++backk] = x;
}

void dequeue(){
    if(!isEmpty()) frontt++;
}

cell frontElement(){
    cell dummy;
    dummy.x=-1;
    dummy.y=-1;
    if(!isEmpty())
        return Q[frontt+1];
    else return dummy;
}

void insertt(int i, int j){
    cell nc;
    nc.x = i;
    nc.y = j;
    enqueue(nc);
}

void print() {
      for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
        cout << dist[i][j] << " " ;
        }
        cout << endl;
      }
}

void run_bfs(){
    while(!isEmpty()) {
        cell ft = frontElement();
        int i = ft.x;
        int j = ft.y;
        dequeue();
        if(i+1<n && dist[i][j]+1 < dist[i+1][j]){
            dist[i+1][j] = dist[i][j]+1;
            insertt(i+1,j);
        }
        if(i-1>=0 && dist[i][j]+1 < dist[i-1][j]){
            dist[i-1][j] = dist[i][j]+1;
            insertt(i-1,j);
        }
        if(j+1<m && dist[i][j]+1 < dist[i][j+1]){
            dist[i][j+1] = dist[i][j]+1;
            insertt(i,j+1);
        }
        if(j-1>=0 && dist[i][j]+1 < dist[i][j-1]){
            dist[i][j-1] = dist[i][j]+1;
            insertt(i,j-1);
        }
    }
}

int main() {

    cell nc;
    cin >> t;
    for(int TC=1;TC<=t;TC++) {
        reset();
        cin >> n >> m;
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                cin >> c;
                dist[i][j] = 10000;
                if(c == '1') {
                    nc.x = i;
                    nc.y = j;
                    dist[i][j] = 0;
                    enqueue(nc);
                }
            }
        }
        run_bfs();
       	cout << "Case #" << TC << endl;
        print();
    }
    return 0;
}
