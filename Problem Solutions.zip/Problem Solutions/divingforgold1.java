import java.util.Scanner;
public class divingforgold1 {
    public static Scanner sc;
    static int[] prime=new int[800];
    static int[] str=new int[30];
    static int k=0,count=0,count1=0;
    static int maxj;
    static int[][] treasure1=new int[30][2];
    static int[] str1=new int[30];

    public static void main(String arg[]) {

        sc=new Scanner(System.in);
        int T,time,w,m;
        int time1=0,gold=0,max=0;

        T=sc.nextInt();
        for(int i=0;i<T;i++) {
            time=sc.nextInt();
            w=sc.nextInt();
            m=sc.nextInt();
            int a=1;
            while(count<m)  {
                a=a*2;
                count++;
            }

            for(int k=0;k<m;k++) {
                treasure1[k][0]=sc.nextInt();
                treasure1[k][1]=sc.nextInt();
            }

            for(int j=1;j<=a;j++) {
                int b=j;
                while(b>0) {
                    for(int k=m-1;k>=0;k--) {
                        str[k]=b%2;
                        b=b/2;
                    }
                }
                gold=0;
                time1=0;
                for(int k=0;k<m;k++){
                    if(str[k]==1) {
                        time1=time1+(3*w*treasure1[k][0]);
                        gold=gold+treasure1[k][1];
                    }
                }
                if((time1<=time)&&(max<gold)) {
                    max=gold;
                    maxj=j;
                }
            }

            System.out.println(max);

            while(maxj>0) {
                for(int k=m-1;k>=0;k--) {
                    str1[k]=maxj%2;
                    if(str1[k]==1)
                        count1++;
                    maxj=maxj/2;
                }
            }
            System.out.println(count1);

            for(int k=0;k<m;k++) {
                if(str1[k]==1)
                    System.out.println(treasure1[k][0]+" "+treasure1[k][1]);
            }
        }
    }
}
