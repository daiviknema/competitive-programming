#include <iostream>
using namespace std;
int prime[10000];
int adjMat[1100][1100];
int t, p1, p2, answer=100000;
int visited[1100];
int id=0;
int sc = -1;
int dt = -1;
struct point
{
    int x;
    int d;
};
point qe[1100*1100];
void getPrimes(){
    int setPrimes[10000];
    for(int i=2;i<10000;i++) setPrimes[i] = 1;
    int first = 2;
    while(first<10000){
        int i=2;
        while(i*first<10000){
            setPrimes[i*first]=0;
            i++;
        }
        first++;
        while(setPrimes[first]==0)first++;
    }

    for(int i=2;i<10000;i++){
        if(i>1000 && setPrimes[i]==1){
            prime[id++] = i;
        }
    }
}

bool isEdge(int n1,int n2){
    int c=0;
    for(int i=0;i<4;i++){
        int d1 = n1%10;
        int d2 = n2%10;
        n1 = n1/10;
        n2 = n2/10;
        c = d1!=d2?c+1:c;
    }
    return (c==1);
}

void fillAdjMat(){
    for(int i=0;i<id;i++)
        for(int j=0;j<id;j++)
            adjMat[i][j] = 0;
    for(int i=0;i<id;i++){
        for(int j=i+1;j<id;j++){
            if(isEdge(prime[i],prime[j]))
			{
                adjMat[i][j] = 1;
                adjMat[j][i] = 1;
            }
        }
    }
}
int bfs(int sc)
{
    point p; int front=-1; int rear = -1;
    p.d = 0;
    p.x = sc;
    qe[++rear] = p;
    while(front!=rear) {
        point p = qe[++front];
        int x = p.x;
        int d = p.d;
        visited[x] = 1;
        if(x == dt)
            return d;
        else{
            for(int i=0;i<id;i++){
                if(adjMat[x][i]==1 && visited[i]==0){
                    point np;
                    np.d = d+1;
                    np.x = i;
                    qe[++rear] = np;
                }
            }
        }
    }
    return -1;
}

int main(){
    getPrimes();
    fillAdjMat();
    cin >> t;
    for(int tc=1;tc<=t;tc++){
        answer=1100;
        for(int i=0;i<id;i++) visited[i] = 0;
        cin >> p1 >> p2;
        for(int i=0;i<id;i++){
            if(prime[i]==p1) sc=i;
            if(prime[i]==p2) dt=i;
        }
        answer = bfs(sc);
        cout << "#" << tc << " ";
        cout << answer;
        cout << endl;

    }
    return 0;
}
