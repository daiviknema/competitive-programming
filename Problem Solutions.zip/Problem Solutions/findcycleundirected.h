#include<stdio.h>

int data[50][50];
int visited[50*50*2];
int flag,N;

void dfs(int i)
 {
    int j;

	if(visited[i])
	{
	 flag=1;
	 return;
	}

	visited[i]=1;

	for(j=1;j<=N;j++)
	 {
	   if(data[i][j])
		   dfs(j);
	 }
	visited[i]=0;
 }

int main()
 {
 
	  int t,T,i,j,s,d;
	  scanf("%d",&T);

	  for(t=1;t<=T;t++)
	    {
	     flag=0;
	     
		 scanf("%d",&N);
		 for(i=0;i<N;i++)
		   {
		    for(j=0;j<N;j++)
			 {
			  data[i][j]=0;
			 }
		  
			 visited[i]=0;
		   }

		 

		 for(i=0;i<N;i++)
		  {
		   scanf("%d %d",&s,&d);
		   data[s][d]=1;
		  }

		 for(i=0;i<N;i++)
		  dfs(i);

		 printf("Case #%d\n",t);

		 if(flag)
			 printf("Cycle possible\n");
		 else
			  printf("Cycle not possible\n");

	    }

	  return  0;
 }