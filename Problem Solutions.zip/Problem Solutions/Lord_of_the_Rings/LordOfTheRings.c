#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int ans;
int n;
int soldiers[21];
int toll[21];

int fun(int city, int cost, int mysoldiers, int battle0, int battle1, int battle2)
{
	if (city == n)
	{
		if (cost < ans)
			ans = cost;
		return 0;
	}

	if (cost > ans)
		return;

	//Pass through the city by paying the toll.
	fun(city + 1, cost + toll[city + 1], mysoldiers, battle0, battle1, battle2);

	//Pass through the city and hire all soldiers by paying double toll.
	fun(city + 1, cost + 2 * toll[city + 1], mysoldiers + soldiers[city + 1], battle0 + soldiers[city + 1], battle1, battle2);

	//Pass through the city by fighting with the soldiers.
	if (mysoldiers >= soldiers[city + 1])
	{
		if (battle2 >= soldiers[city + 1])
		{
			int fight = battle2;
			battle2 = battle1;
			battle1 = battle0;
			battle0 = 0;
			fun(city + 1, cost, mysoldiers-soldiers[city+1], battle0, battle1, battle2);
		}
		else if (battle2 + battle1 >= soldiers[city + 1])
		{
			battle2 = battle1 - (soldiers[city + 1] - battle2);
			battle1 = battle0;
			battle0 = 0;
			fun(city + 1, cost, mysoldiers - soldiers[city + 1], battle0, battle1, battle2);
		}
		else if (battle2 + battle1 + battle0 >= soldiers[city + 1])
		{
			battle1 = battle0 - (soldiers[city + 1] - battle2 - battle1);
			battle2 = 0;
			battle0 = 0;
			fun(city + 1, cost, mysoldiers - soldiers[city + 1], battle0, battle1, battle2);
		}
	}
}

int main()
{
	int T;
	scanf("%d", &T);

	int t;
	for (t = 1; t <= T; t++)
	{
		ans = 999999;
		scanf("%d", &n);

		int i, j, k;
		for (i = 0; i < 21; i++)
		{
			soldiers[i] = 0;
			toll[i] = 0;
		}

		for (i = 1; i <= n; i++)
			scanf("%d %d", &soldiers[i],&toll[i]);

		fun(0, 0, 0, 0, 0, 0);

		printf("#%d %d\n", t, ans);
	}
	return 0;
}