#include<stdio.h>
int nodes[101];
int visited[101];
int candidates[101];
int adjMat[101][101];
int t,m,n,x,y, c=0;
int answer = 0;

void init(){
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++)   adjMat[i][j] = 0;
        visited[i] = 0;
    }
    c=0;
    answer = 0;
}

void dfs(int v){
    visited[v] = 1;
    for(int i=1;i<=n;i++){
        if(adjMat[v][i]==1 && visited[i]==0)
            dfs(i);
    }
}

int main() {
    cin >> t;
    for(int tc=1;tc<=t;tc++) {
		scanf("%d %d", &n, &m);
        init();
        for(int j=0;j<m;j++){
			scanf("%d %d", &x, &y);
            adjMat[x][y] = 1;
        }

        for(int j=1;j<=n;j++){
            if(visited[j]==0){
                dfs(j); candidates[c++] = j;
            }
        }

        for(int j=1;j<=n;j++)   visited[j] = 0;

        for(int i=c-1;i>=0;i--){
            if(visited[candidates[i]]==0){
                dfs(candidates[i]);
                answer++;
            }
        }
		printf("Case %d: %d\n",tc,answer);
    }
    return 0;
}
